
# Proyecto A1T4 - FreeRTOS + NeoPixel + STM32

Este proyecto contiene:
- Configuración PlatformIO
- FreeRTOS para STM32
- Animación en WS2812B usando Adafruit NeoPixel

Listo para compilar en VS Code.
