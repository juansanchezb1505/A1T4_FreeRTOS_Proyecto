
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <Adafruit_NeoPixel.h>

#define LED_PIN PA7
#define NUM_LEDS 16

Adafruit_NeoPixel strip(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);

void tareaBarrer(void *pvParameters) {
    while (1) {
        for (int i = 0; i < NUM_LEDS; i++) {
            strip.clear();
            strip.setPixelColor(i, strip.Color(0, 150, 255));
            strip.show();
            vTaskDelay(pdMS_TO_TICKS(100));
        }
    }
}

void tareaRespirar(void *pvParameters) {
    int brillo = 0;
    int delta = 5;

    while (1) {
        strip.setBrightness(brillo);
        for (int i = 0; i < NUM_LEDS; i++) {
            strip.setPixelColor(i, strip.Color(255, 50, 0));
        }
        strip.show();

        brillo += delta;
        if (brillo >= 150 || brillo <= 5) delta = -delta;

        vTaskDelay(pdMS_TO_TICKS(30));
    }
}

void setup() {
    strip.begin();
    strip.show();

    xTaskCreate(tareaBarrer, "barrer", 256, NULL, 1, NULL);
    xTaskCreate(tareaRespirar, "respirar", 256, NULL, 1, NULL);

    vTaskStartScheduler();
}

void loop() {}
